export const invert = c => c === 'w' ? 'b' : 'w';
export function categoryValue(category) {
  if (category === 'win') return 1;
  if (category === 'loss') return -1;
  if (['draw','cursed-win','blessed-loss'].includes(category)) return 0;
  return null; // Never pretend rounded/unknown Syzygy categories are exact.
}
export function perspective(result, turn, side) {
  if (result?.category) {
    const v = categoryValue(result.category);
    return v === null ? null : v === 0 ? 0 : v * (turn === side ? 1 : -1);
  }
  return null;
}
export function evaluateMove(before, after, side, beforeTurn, afterTurn) {
  const b = perspective(before,beforeTurn,side), a = perspective(after,afterTurn,side);
  if (b !== null && a !== null) return {exact:true, mistake:a < b, before:b, after:a};
  const cp = (r,t) => r?.mate != null ? Math.sign(r.mate)*100000*(t===side?1:-1) : r?.cp != null ? r.cp*(t===side?1:-1) : null;
  const x=cp(before,beforeTurn), y=cp(after,afterTurn);
  return {exact:false, mistake:x!==null && y!==null && x-y>120, before:x, after:y};
}
export function terminal(chess, side, goal) {
  if (chess.isCheckmate()) {
    const won=chess.turn()!==side;
    return {title:won?'Checkmate. Well played.':'Checkmate — try again.',success:won,reason:won?'You converted the position into a win.':'The defending side was checkmated.'};
  }
  if (chess.isDraw()) {
    const reason=chess.isStalemate()?'Stalemate':chess.isThreefoldRepetition()?'Threefold repetition':chess.isInsufficientMaterial()?'Insufficient mating material':'Fifty-move rule';
    return {title:goal==='draw'?'Draw secured.':'The game is drawn.',success:goal==='draw',reason:reason+'. '+(goal==='draw'?'You achieved the defensive goal.':'A winning exercise requires a win. Review the last moves.')};
  }
  return null;
}
export function uciMove(uci) {return {from:uci.slice(0,2),to:uci.slice(2,4),promotion:uci[4]||'q'};}
export const fenKey = fen => fen.split(' ').slice(0,5).join(' ');
export function loadProgress(storage) {
  try {const p=JSON.parse(storage.getItem('endgame-lab-v2')||'{}'); return p && typeof p==='object' && !Array.isArray(p)?p:{};} catch {return {};}
}
export function nextReview(record, now=Date.now()) {
  if (!record?.passed) return true;
  return now-(record.last||0) > (record.streak>=3?7:record.streak>=2?3:1)*86400000;
}
export function mistakeExplanation(chess, played, beforeChess, beforeResult, verdict) {
  const names={p:'pawn',n:'knight',b:'bishop',r:'rook',q:'queen',k:'king'};
  const capture=chess.moves({verbose:true}).find(m=>m.to===played.to&&m.captured);
  let text=capture?`${chess.turn()==='w'?'White':'Black'} can play ${capture.san}, capturing your ${names[capture.captured]} on ${played.to}. `:'';
  const best=beforeResult?.moves?.[0]?.uci||beforeResult?.best;
  if(best)try{const m=beforeChess.move(uciMove(best));text+=verdict.exact?`Before ${played.san}, ${m.san} preserved ${verdict.before===1?'the win':verdict.before===0?'the draw':'the best available result'}. `:`Stockfish suggests ${m.san} instead at this search time. `;}catch{}
  text+=verdict.exact?(verdict.after===0?'The resulting position is a theoretical draw. ':verdict.after===-1?'The resulting position is a forced loss with best play. ':'The outcome has changed. '):'The estimated evaluation dropped by more than a pawn; this is not an exact result. ';
  return text+'Use Retry move to compare another choice.';
}
