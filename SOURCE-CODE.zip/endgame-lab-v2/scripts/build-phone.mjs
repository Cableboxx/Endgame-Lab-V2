import {build} from 'esbuild';
import {readFile,writeFile,readdir,mkdir,copyFile} from 'node:fs/promises';
import path from 'node:path';
const root=process.cwd(),out=path.join(root,'phone-dist');await mkdir(out,{recursive:true});
const dataURI=async(p,type)=>'data:'+type+';base64,'+(await readFile(p)).toString('base64');
const pieces={};for(const name of await readdir('assets/pieces'))if(name.endsWith('.svg'))pieces[name.slice(0,-4)]=await dataURI('assets/pieces/'+name,'image/svg+xml');
const curriculum=JSON.parse(await readFile('data/curriculum.json','utf8')),practice=JSON.parse(await readFile('data/practice.json','utf8')),cache=JSON.parse(await readFile('data/tablebase-cache.json','utf8'));
const bundled=await build({entryPoints:['app.js'],bundle:true,write:false,format:'esm',target:'es2022',legalComments:'inline',plugins:[{name:'phone-assets',setup(b){b.onLoad({filter:/(?:^|\/)(app|engine)\.js$/},async args=>{let text=await readFile(args.path,'utf8');if(path.basename(args.path)==='app.js'){
text='const PHONE_PIECES='+JSON.stringify(pieces)+';\n'+text;
text=text.replaceAll('./assets/pieces/${p.color}${p.type.toUpperCase()}.svg','${PHONE_PIECES[p.color+p.type.toUpperCase()]}').replaceAll('./assets/pieces/${color}${p.toUpperCase()}.svg','${PHONE_PIECES[color+p.toUpperCase()]}');
const start=text.lastIndexOf("try{\n const [r,p]="),end=text.indexOf('lessons=(Array.isArray(data)',start);if(start<0||end<0)throw new Error('Course entrypoint not found');text=text.slice(0,start)+'try{\n const data='+JSON.stringify(curriculum)+',transfer='+JSON.stringify(practice)+';\n '+text.slice(end);
}else{text='const PHONE_CACHE='+JSON.stringify(cache)+';\n'+text;text=text.replaceAll('./assets/engine/stockfish-18-lite-single.js','./stockfish-18-lite-single.js').replace(/  async seed\(\)\{[^\n]*\}/,'  async seed(){for(const [k,v] of Object.entries(PHONE_CACHE))this.cache.set(k,v);}');}
return {contents:text,loader:'js',resolveDir:path.dirname(args.path)};});}}]});
let html=await readFile('index.html','utf8');const icon=await dataURI('favicon.svg','image/svg+xml');
html=html.replaceAll('./favicon.svg',icon).replace('<link rel="stylesheet" href="./styles.css">','<style>'+await readFile('styles.css','utf8')+'</style>');
const script=bundled.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
html=html.replace('<script type="module" src="./app.js"></script>',()=>'<script type="module">'+script+'</script>');
await writeFile(path.join(out,'index.html'),html);
for(const name of ['stockfish-18-lite-single.js','stockfish-18-lite-single.wasm'])await copyFile('assets/engine/'+name,path.join(out,name));
for(const name of ['LICENSE','THIRD_PARTY.md','VALIDATION.md'])await copyFile(name,path.join(out,name));
await copyFile('assets/CHESS-JS-LICENSE',path.join(out,'CHESS-JS-LICENSE.txt'));
await copyFile('assets/engine/AUTHORS',path.join(out,'STOCKFISH-AUTHORS.txt'));
await copyFile('IPHONE-UPLOAD.txt',path.join(out,'README.txt'));
console.log('Phone upload edition ready in phone-dist/: three runtime files, no nested asset folders.');
