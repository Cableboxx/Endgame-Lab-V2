import {mkdir,copyFile} from 'node:fs/promises';
await mkdir('assets/engine',{recursive:true});
for(const n of ['stockfish-18-lite-single.js','stockfish-18-lite-single.wasm'])await copyFile('node_modules/stockfish/src/'+n,'assets/engine/'+n);
await copyFile('node_modules/chess.js/dist/esm/chess.js','assets/chess.js');
await copyFile('node_modules/chess.js/dist/esm/chess.js.map','assets/chess.js.map');
console.log('Pinned rules library and engine assets ready.');
