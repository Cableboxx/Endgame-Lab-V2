import {cp,mkdir,rm} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
for(const path of ['index.html','styles.css','app.js','engine.js','core.js','learning.js','completion.js','opponent.js','favicon.svg','assets','data']) await cp(path,'dist/'+path,{recursive:true});
console.log('Static site ready in dist/');
