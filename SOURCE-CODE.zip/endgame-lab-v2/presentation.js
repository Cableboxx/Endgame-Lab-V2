// Use the same Cburnett SVG assets as the playable board, never platform chess glyphs.
const subjects={
 'knight-circuit':['n','p'],'bishop-blockade':['b','p'],'sacrifice-to-fortress':['n','p'],'exchange-to-draw':['r','b'],'passer-versus-knight':['p','n'],'rook-pawn-cutoff':['r','p'],'short-checks':['r','k'],'queen-versus-minor':['q','b'],'race-with-check':['q','p'],'queen-blockade-tempo':['q','p'],'queen-stalemate-defense':['q','p'],'queen-active-king':['q','k'],'vancura':['r','p'],'second-pawn-file':['r','p'],'active-rook-counterplay':['r','k'],'bishop-knight-coordination':['b','n'],'two-weaknesses':['r','n'],
 'queen-box':['q'], 'rook-box':['r'], 'two-rooks':['r','r'],
 'wrong-bishop':['b','p'], 'philidor':['r','p'], 'lucena':['r','p'],
 'connected-passers':['r','p'], 'rook-behind':['r','p'],
 'pawn-breakthrough':['p','p'], 'majority-lever':['p','p'],
 'outside-decoy':['p','k'], 'separated-passers':['p','p'], 'protected-anchor':['p','k']
};
export function lessonPieces(lesson){return (subjects[lesson.lessonId||lesson.id]||['k','p']).map(type=>({color:'w',type}));}
export function coursePieces(id){return (id==='pawn-play'?['p','p']:id==='practical'?['r','b']:id==='advanced'?['q','n']:['k','r']).map(type=>({color:'w',type}));}
