// Use the same Cburnett SVG assets as the playable board, never platform chess glyphs.
const subjects={
 'queen-box':['q'], 'rook-box':['r'], 'two-rooks':['r','r'],
 'wrong-bishop':['b','p'], 'philidor':['r','p'], 'lucena':['r','p'],
 'connected-passers':['r','p'], 'rook-behind':['r','p'],
 'pawn-breakthrough':['p','p'], 'majority-lever':['p','p'],
 'outside-decoy':['p','k'], 'separated-passers':['p','p'], 'protected-anchor':['p','k']
};
export function lessonPieces(lesson){return (subjects[lesson.lessonId||lesson.id]||['k','p']).map(type=>({color:'w',type}));}
export function coursePieces(id){return (id==='pawn-play'?['p','p']:['k','r']).map(type=>({color:'w',type}));}
