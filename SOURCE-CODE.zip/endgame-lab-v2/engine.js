import {fenKey,categoryValue,evaluateMove} from './core.js';
import {guidedReply} from './opponent.js';
export class Engine {
  constructor(onstatus=()=>{}) {this.onstatus=onstatus;this.queue=Promise.resolve();this.worker=null;this.ready=null;}
  init() {
    if(this.ready)return this.ready;
    this.onstatus('Loading Stockfish…');
    this.ready=new Promise((resolve,reject)=>{
      let timer;
      try {
        this.worker=new Worker(new URL('./assets/engine/stockfish-18-lite-single.js',import.meta.url));
        timer=setTimeout(()=>{this.worker?.terminate();this.ready=null;reject(new Error('Engine startup timed out. Check the engine files and retry.'));},25000);
        this.worker.onerror=()=>{clearTimeout(timer);this.ready=null;reject(new Error('Stockfish could not start. Serve this project over HTTP, with its matching WASM file.'));};
        this.worker.onmessage=e=>{
          const line=String(e.data);
          if(line==='uciok'){this.worker.postMessage('setoption name Hash value 16');this.worker.postMessage('isready');}
          if(line==='readyok'){clearTimeout(timer);this.onstatus('Stockfish 18 · ready');resolve();}
        };
        this.worker.postMessage('uci');
      } catch(e){clearTimeout(timer);this.ready=null;reject(e);}
    });
    this.ready=this.ready.catch(e=>{this.ready=null;throw e;});
    return this.ready;
  }
  search(fen,ms=600,options={}) {
    const run=async()=>{
      await this.init();
      return new Promise((resolve,reject)=>{
        let result={},timer=setTimeout(()=>{this.worker.terminate();this.ready=null;reject(new Error('Engine search timed out. Try again.'));},12000);
        this.worker.onmessage=e=>{
          const line=String(e.data), score=line.match(/score (cp|mate) (-?\d+)/), pv=line.match(/ pv (.+)$/);
          if(score){result.cp=undefined;result.mate=undefined;result[score[1]]=Number(score[2]);}
          if(pv)result.pv=pv[1].split(' ');
          const best=line.match(/^bestmove (\S+)/);
          if(best){clearTimeout(timer);resolve({...result,best:best[1],source:'engine'});}
        };
        this.worker.postMessage('position fen '+fen);
        const legal=(options.searchmoves||[]).filter(m=>/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(m));
        this.worker.postMessage('go movetime '+ms+(legal.length?' searchmoves '+legal.join(' '):''));
      });
    };
    const p=this.queue.then(run,run);this.queue=p.catch(()=>{});return p;
  }
}
export class Oracle {
  constructor(engine){this.engine=engine;this.cache=new Map();this.pending=new Map();this.disabledUntil=0;}
  async seed(){try{const r=await fetch('./data/tablebase-cache.json');if(r.ok)for(const [k,v] of Object.entries(await r.json()))this.cache.set(k,v);}catch{}}
  async tablebase(fen) {
    const key=fenKey(fen);
    if(this.cache.has(key))return this.cache.get(key);
    if(this.pending.has(key))return this.pending.get(key);
    if(Date.now()<this.disabledUntil)return null;
    if((fen.split(' ')[0].match(/[a-z]/gi)||[]).length>7)return null;
    const task=(async()=>{
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),3500);
      try{
        const r=await fetch('https://tablebase.lichess.ovh/standard?fen='+encodeURIComponent(fen),{signal:controller.signal});
        if(!r.ok)throw new Error('Tablebase unavailable');
        const d=await r.json();if(!d.category||!d.moves)return null;
        const result={...d,source:'tablebase'};this.cache.set(key,result);return result;
      }catch{this.disabledUntil=Date.now()+60000;return null;}finally{clearTimeout(timer);this.pending.delete(key);}
    })();this.pending.set(key,task);return task;
  }
  async analyse(fen){const tb=await this.tablebase(fen);if(tb&&categoryValue(tb.category)!==null)return tb;return this.engine.search(fen);}
  async reviewMove(beforeFen,afterFen,side,before,after){
    const beforeTurn=beforeFen.split(' ')[1],afterTurn=afterFen.split(' ')[1];
    if(categoryValue(before?.category)!==null&&categoryValue(after?.category)!==null)
      return {before,after,verdict:evaluateMove(before,after,side,beforeTurn,afterTurn)};
    // Compare like with like when a move crosses tablebase coverage or the API is unavailable.
    // Keep the original exact result for the board label, but obtain two engine scores for feedback.
    const scored=r=>Number.isFinite(r?.cp)||Number.isFinite(r?.mate);
    const estimatedBefore=scored(before)?before:await this.engine.search(beforeFen);
    const estimatedAfter=scored(after)?after:await this.engine.search(afterFen);
    if(!scored(estimatedBefore)||!scored(estimatedAfter))throw new Error('A complete before-and-after evaluation is not available.');
    return {before:estimatedBefore,after:estimatedAfter,verdict:evaluateMove(estimatedBefore,estimatedAfter,side,beforeTurn,afterTurn)};
  }
  async reply(fen,options={}){
    if(options.policy==='free')return this.engine.search(fen);
    const r=await this.analyse(fen);
    if(options.policy==='guided-defense'&&r.source==='tablebase')return guidedReply(fen,r,this.engine,options);
    let move=r.moves?.[0];
    // Prefer a queen to an equally good underpromotion. Never change the exact outcome.
    if(move?.uci.length===5&&move.uci[4]!=='q'&&categoryValue(move.category)!==null){
      move=r.moves.find(m=>m.uci===move.uci.slice(0,4)+'q'&&categoryValue(m.category)===categoryValue(move.category))||move;
    }
    return {...r,best:move?.uci||r.best};
  }
}
