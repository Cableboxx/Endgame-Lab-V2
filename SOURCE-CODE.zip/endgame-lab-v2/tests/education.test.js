import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Chess} from '../assets/chess.js';
import {Oracle} from '../engine.js';
import {fenKey,evaluateMove,uciMove} from '../core.js';
import {exerciseResult,instructionalMilestone} from '../completion.js';
import {guidedReply,preservingMoves,pressureFeatures,sourceReply} from '../opponent.js';
const lessons=JSON.parse(readFileSync('data/curriculum.json'));
const cache=JSON.parse(readFileSync('data/tablebase-cache.json'));
const cases=JSON.parse(readFileSync('tests/educational-regressions.json'));
const lesson=id=>lessons.find(l=>l.id===id);
test('source-derived rook g7 does not protect a promoted queen on h8',()=>{
 const c=new Chess(cases.unguarded_promotion.fen);
 assert.equal(c.get('g7').type,'r');assert.equal(c.get('h8').type,'q');
 assert.equal(c.attackers('h8','w').includes('g7'),false);assert.equal(c.isAttacked('h8','w'),false);
 assert.ok(c.moves({verbose:true}).some(m=>m.from==='h1'&&m.to==='h8'&&m.captured==='q'));
});
test('the vulnerable promotion actually loses the source position’s theoretical win',()=>{
 assert.equal(cases.before_unguarded_promotion.category,'win');assert.equal(cases.unguarded_promotion.category,'draw');
 assert.equal(evaluateMove(cases.before_unguarded_promotion,cases.unguarded_promotion,'w','w','b').mistake,true);
});
test('promotion never completes a winning exercise, even when still objectively winning',()=>{
 const l=lesson('opposition'),c=new Chess(l.fen);let promotion;
 for(const step of l.line){const m=c.move(step.san);if(m.promotion)promotion=m;}
 assert.ok(promotion);assert.equal(exerciseResult(c,l),null);
 const mark=instructionalMilestone(promotion,{category:'loss'},c,l,8);assert.match(mark.title,/keep playing/);assert.match(mark.text,/checkmate/);
});
test('vulnerable queen promotion stays playable and gives no completion credit',()=>{
 const c=new Chess(cases.before_unguarded_promotion.fen),m=c.move('h8=Q');
 assert.equal(exerciseResult(c,lesson('connected-passers')),null);
 assert.match(instructionalMilestone(m,cases.unguarded_promotion,c,lesson('connected-passers'),7).text,/drawn/);
});
test('twenty moves defended is feedback only, never an exercise result',()=>{
 const l=lesson('defensive-opposition'),c=new Chess(l.fen),m=c.moves({verbose:true})[0];
 assert.equal(exerciseResult(c,l),null);const r=instructionalMilestone(m,{category:'draw'},c,l,20);assert.match(r.text,/not exercise completion/);assert.equal(exerciseResult(c,l),null);
});
test('actual checkmate and actual defensive draw still finish correctly',()=>{
 const l=lesson('queen-box'),c=new Chess(l.fen);l.line.forEach(m=>c.move(m.san));assert.equal(exerciseResult(c,l).success,true);
 const d=lesson('rook-pawn'),b=new Chess(d.fen);d.line.forEach(m=>b.move(m.san));assert.equal(b.isStalemate(),true);assert.equal(exerciseResult(b,d).success,true);
});
test('guided defensive play rejects a voluntary pawn surrender when sound pressure exists',async()=>{
 const fen=cases.defensive_pressure.fen,r=cache[fenKey(fen)],exercise=lesson('defensive-opposition');
 assert.equal(r.moves[0].san,'d6','regression reproduces default tablebase ordering');
 assert.equal(pressureFeatures(fen,'d5d6').instantDrawReply,true);
 assert.equal(pressureFeatures(fen,'d4e5').instantDrawReply,false);
 const selected=await guidedReply(fen,r,{search:()=>{throw new Error('published preserving reply should be used');}},{exercise});
 assert.equal(selected.best,'d4e5');assert.equal(selected.selection,'source-preserving');
 assert.ok(preservingMoves(fen,r).some(m=>m.uci===selected.best));
});
test('guided play may sacrifice a pawn when every preserving alternative also concedes a draw',async()=>{
 const l=lesson('square-rule'),c=new Chess(l.fen);l.line.slice(0,9).forEach(m=>c.move(m.san));
 const fen=c.fen(),root=cache[fenKey(fen)];assert.ok(root,'published promotion position is cached');
 const best=await guidedReply(fen,root,{search:async(_f,_ms,options)=>({best:options.searchmoves[0],source:'engine'})},{exercise:l});
 const after=new Chess(fen);after.move(uciMove(best.best));assert.ok(preservingMoves(fen,root).some(m=>m.uci===best.best));
 assert.equal(best.best,'h7h8q','the verified final capture must not be universally prohibited');
});
test('guided selection only offers objective preserving moves to the engine',async()=>{
 const fen=cases.defensive_pressure.fen,r=cache[fenKey(fen)],calls=[];
 const x=await guidedReply(fen,r,{search:async(f,ms,o)=>{calls.push(o.searchmoves);return {best:o.searchmoves[0]};}},{history:[]});
 const allowed=new Set(preservingMoves(fen,r).map(m=>m.uci));assert.ok(allowed.has(x.best));for(const pool of calls)for(const m of pool)assert.ok(allowed.has(m));
});
test('free play uses unrestricted engine search, ignoring guided tablebase preferences',async()=>{
 const fen=cases.defensive_pressure.fen,calls=[],o=new Oracle({search:async(...args)=>{calls.push(args);return {best:'d5d6',source:'engine'};}});
 o.analyse=()=>{throw new Error('free opponent must not be chosen by tablebase');};
 const r=await o.reply(fen,{policy:'free',exercise:lesson('defensive-opposition')});assert.equal(r.best,'d5d6');assert.deepEqual(calls,[[fen]]);
});
test('all published reply suggestions are legal library-verified moves',()=>{
 for(const l of lessons){const c=new Chess(l.fen);for(const step of l.line){const suggested=sourceReply(c.fen(),l);assert.ok(suggested);assert.ok(new Chess(c.fen()).move(uciMove(suggested)));c.move(step.san);}}
});
test('repeated source positions advance to the later instructional reply rather than looping the first one',()=>{
 const l=lesson('defensive-opposition'),c=new Chess(l.fen);l.line.slice(0,7).forEach(m=>c.move(m.san));
 assert.equal(sourceReply(c.fen(),l),'d4c5');
});
test('guided policy remains legal and result-preserving throughout all audited defensive source positions', {timeout:60000},async()=>{
 const audit=JSON.parse(readFileSync('tests/defensive-source-audit.json')),extra=JSON.parse(readFileSync('data/practice.json'));
 assert.equal(audit.length,79);
 for(const p of audit){assert.equal(p.verifiedExpectedOutcome,true,p.exerciseId+' '+p.fen);const r=cache[fenKey(p.fen)],e=[...lessons,...extra].find(e=>e.id===p.exerciseId);
  const reply=await guidedReply(p.fen,r,{search:async(_f,_ms,o)=>({best:o.searchmoves[0]})},{exercise:e});
  assert.ok(preservingMoves(p.fen,r).some(m=>m.uci===reply.best),p.exerciseId);assert.ok(new Chess(p.fen).move(uciMove(reply.best)));
 }
});
test('instructional piece-protection claims are verified by the actual board’s attack map',()=>{
 let checked=0;
 for(const l of lessons){const c=new Chess(l.fen);for(const step of l.line){c.move(step.san);for(const claim of step.attackChecks||[]){const p=c.get(claim.from);assert.ok(p,l.id+' '+claim.from);assert.equal(c.attackers(claim.to,p.color).includes(claim.from),claim.attacks,l.id+' '+step.san+' '+claim.from+'→'+claim.to);checked++;}}}
 assert.ok(checked>=40);
});
test('when resistance is exhausted, guided defense can finish with the published stalemate',async()=>{
 const l=lesson('defensive-opposition'),c=new Chess(l.fen);l.line.slice(0,-1).forEach(m=>c.move(m.san));
 const fen=c.fen(),r=cache[fenKey(fen)];assert.ok(r);
 const answer=await guidedReply(fen,r,{search:async(_f,_ms,o)=>({best:o.searchmoves[0]})},{exercise:l});
 assert.equal(answer.best,'c6d6');c.move(uciMove(answer.best));assert.equal(c.isStalemate(),true);
});
