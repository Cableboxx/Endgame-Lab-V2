import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {Chess} from '../assets/chess.js';
import {categoryValue,perspective,evaluateMove,terminal,fenKey,loadProgress,nextReview,uciMove,mistakeExplanation} from '../core.js';
const lessons=JSON.parse(readFileSync(new URL('../data/curriculum.json',import.meta.url))).filter(l=>l.section==='core');
test('curriculum has unique IDs, traced source chapters, substantive notes and goals',()=>{
 assert.equal(lessons.length,16);assert.equal(new Set(lessons.map(l=>l.id)).size,16);
 for(const l of lessons){assert.match(l.source.url,/^https:\/\/lichess.org\/study\/[\w]+\/[\w]+$/);assert.ok(l.source.chapter);assert.ok(l.source.author);assert.ok(l.concept.length>30);assert.equal(l.plan.length,3);assert.ok(l.pitfall.length>20);assert.ok(['win','draw'].includes(l.goal));assert.ok(['w','b'].includes(l.side));assert.ok(l.line.length>=3);}
});
for(const l of lessons)test('legal source line: '+l.id,()=>{const c=new Chess(l.fen);assert.equal(c.isGameOver(),false);for(const m of l.line){assert.ok(m.text.length>10);assert.ok(c.move(m.san));}});
test('all shipped chess piece images and engine WASM are present',()=>{for(const c of 'wb')for(const t of 'KQRBNP')assert.ok(readFileSync(new URL('../assets/pieces/'+c+t+'.svg',import.meta.url),'utf8').includes('<svg'));assert.ok(readFileSync(new URL('../assets/engine/stockfish-18-lite-single.wasm',import.meta.url)).length>1000000);});
test('exact outcome categories respect 50-move rule and uncertain values',()=>{for(const [c,v]of Object.entries({win:1,loss:-1,draw:0,'cursed-win':0,'blessed-loss':0}))assert.equal(categoryValue(c),v);for(const c of ['unknown','maybe-win','maybe-loss','syzygy-win','syzygy-loss',undefined])assert.equal(categoryValue(c),null);});
test('tablebase perspective changes sign exactly once',()=>{assert.equal(perspective({category:'win'},'b','w'),-1);assert.equal(perspective({category:'loss'},'b','w'),1);assert.equal(perspective({category:'draw'},'b','w'),0);});
test('losing a win and losing a draw are mistakes',()=>{assert.equal(evaluateMove({category:'win'},{category:'draw'},'w','w','b').mistake,true);assert.equal(evaluateMove({category:'draw'},{category:'win'},'w','w','b').mistake,true);});
test('winning alternatives are accepted without requiring source move',()=>{assert.deepEqual(evaluateMove({category:'win'},{category:'loss'},'w','w','b'),{exact:true,mistake:false,before:1,after:1});});
test('black defensive moves evaluated from black side',()=>{assert.equal(evaluateMove({category:'draw'},{category:'win'},'b','b','w').mistake,true);assert.equal(evaluateMove({category:'draw'},{category:'draw'},'b','b','w').mistake,false);});
test('fallback engine estimates invert side to move',()=>{const x=evaluateMove({cp:400},{cp:-390},'w','w','b');assert.equal(x.mistake,false);assert.equal(x.exact,false);assert.equal(evaluateMove({cp:400},{cp:40},'w','w','b').mistake,true);});
test('unknown categories never produce exact verdict',()=>assert.equal(evaluateMove({category:'maybe-win'},{category:'loss'},'w','w','b').exact,false));
function endOf(id){const l=lessons.find(l=>l.id===id),c=new Chess(l.fen);for(const m of l.line)c.move(m.san);return c;}
test('sourced queen mate scores correctly for both sides',()=>{const c=endOf('queen-box');assert.equal(c.isCheckmate(),true);assert.equal(terminal(c,'w','win').success,true);assert.equal(terminal(c,'b','draw').success,false);});
test('stalemate is a success for defender, never for win objective',()=>{const c=endOf('rook-pawn');assert.equal(c.isStalemate(),true);assert.equal(terminal(c,'b','draw').success,true);assert.equal(terminal(c,'w','win').success,false);});
test('insufficient material ends square-rule defense correctly',()=>{const c=endOf('square-rule');assert.equal(c.isInsufficientMaterial(),true);assert.equal(terminal(c,'b','draw').success,true);});
test('fifty-move draw handled without classifying initial position as draw',()=>{const l=lessons.find(l=>l.id==='rook-box'),c=new Chess(l.fen);assert.equal(terminal(c,l.side,l.goal),null);const f=l.fen.split(' ');f[4]='100';const d=new Chess(f.join(' '));assert.equal(terminal(d,l.side,l.goal).success,false);assert.match(terminal(d,l.side,l.goal).reason,/Fifty/);});
test('legal pawn promotions include all four choices',()=>{let found=false;for(const l of lessons){const c=new Chess(l.fen);for(const m of l.line){const promotions=c.moves({verbose:true}).filter(x=>x.promotion);if(promotions.length){assert.deepEqual([...new Set(promotions.map(x=>x.promotion))].sort(),['b','n','q','r']);found=true;}c.move(m.san);}}assert.ok(found);});
test('cache keys retain halfmove counter',()=>{const f=lessons[0].fen;assert.notEqual(fenKey(f),fenKey(f.replace(' 0 1',' 99 1')));assert.equal(fenKey(f),fenKey(f.replace(' 0 1',' 0 23')));});
test('corrupt progress cannot break loading',()=>{assert.deepEqual(loadProgress({getItem:()=>'{bad'}),{});assert.deepEqual(loadProgress({getItem:()=>null}),{});assert.deepEqual(loadProgress({getItem:()=> '[]'}),{});});
test('review scheduling is spaced by successful repetitions',()=>{const n=2000000000;assert.equal(nextReview({},n),true);assert.equal(nextReview({passed:true,streak:1,last:n-86400001},n),true);assert.equal(nextReview({passed:true,streak:2,last:n-86400001},n),false);assert.equal(nextReview({passed:true,streak:3,last:n-7*86400000-1},n),true);});
test('UCI promotion conversion',()=>assert.deepEqual(uciMove('e7e8n'),{from:'e7',to:'e8',promotion:'n'}));
test('application uses only project-relative asset imports for GitHub Pages subpaths',()=>{for(const f of ['index.html','app.js','engine.js']){const text=readFileSync(new URL('../'+f,import.meta.url),'utf8');assert.ok(!/\b(?:src|href)=["']\/(?!\/)/.test(text));}});
test('all sampled tablebase positions match their stated learner goals',()=>{const report=JSON.parse(readFileSync('tests/validation-curriculum.json','utf8'));assert.ok(report);const cache=JSON.parse(readFileSync('data/tablebase-cache.json','utf8'));assert.ok(Object.keys(cache).length>=64);for(const l of lessons){const r=cache[fenKey(l.fen)];assert.ok(r,'missing initial tablebase: '+l.id);assert.equal(perspective(r,new Chess(l.fen).turn(),l.side),l.goal==='win'?1:0);}});

test('mistake feedback identifies a hanging queen and a verified alternative',()=>{const l=lessons.find(l=>l.id==='queen-box'),c=new Chess(l.fen),m=c.move('Qc4+');const text=mistakeExplanation(c,m,new Chess(l.fen),{moves:[{uci:'c3b4'}]},{exact:true,before:1,after:0});assert.match(text,/Kxc4/);assert.match(text,/queen on c4/);assert.match(text,/Qb4 preserved the win/);});
test('retrying a move by undo preserves threefold repetition history',()=>{const c=new Chess(lessons.find(l=>l.id==='queen-box').fen);for(const m of ['Qb4','Kc6','Qc3+','Kd5','Qb4','Kc6','Qc3+','Kd5'])c.move(m);assert.equal(c.isThreefoldRepetition(),true);const ply=c.history().length;c.move('Qb4');while(c.history().length>ply)c.undo();assert.equal(c.isThreefoldRepetition(),true);});
test('large estimates that both remain decisive are not treated as a lost win',()=>{
 assert.equal(evaluateMove({cp:1113},{cp:-887},'w','w','b').mistake,false);
 assert.equal(evaluateMove({cp:1113},{cp:0},'w','w','b').mistake,true);
});
