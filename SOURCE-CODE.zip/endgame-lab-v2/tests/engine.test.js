import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {createInterface} from 'node:readline';
import {Chess} from '../assets/chess.js';
import {uciMove} from '../core.js';
import {Engine,Oracle} from '../engine.js';
const workers=[];
class NodeWorker {
 constructor(){this.child=spawn(process.execPath,['node_modules/stockfish/src/stockfish-18-lite-single.js'],{stdio:['pipe','pipe','pipe']});workers.push(this);createInterface({input:this.child.stdout}).on('line',line=>this.onmessage?.({data:line}));this.child.on('error',e=>this.onerror?.(e));}
 postMessage(s){this.child.stdin.write(s+'\n');}
 terminate(){this.child.kill();}
}
test('real bundled Stockfish handshake, queued searches, and all course practice starts', {timeout:30000},async()=>{
 global.Worker=NodeWorker;
 const statuses=[],engine=new Engine(s=>statuses.push(s));
 try{
  await engine.init();assert.ok(statuses.includes('Stockfish 18 · ready'));
  const lessons=JSON.parse(readFileSync('data/curriculum.json','utf8'));
  const answers=await Promise.all(lessons.map(l=>engine.search(l.fen,80)));
  answers.forEach((r,i)=>{assert.ok(r.best);assert.ok(new Chess(lessons[i].fen).move(uciMove(r.best)));assert.ok(Number.isFinite(r.cp)||Number.isFinite(r.mate));});
  const constrained=await engine.search('8/3k4/8/3P4/3K4/8/8/8 w - - 1 2',80,{searchmoves:['d4e5']});assert.equal(constrained.best,'d4e5','real UCI search respects preserving root constraints');
  assert.equal(workers.length,1,'searches reuse the same engine worker');
 }finally{for(const w of workers)w.terminate();}
});
test('tablebase cache respects halfmove clocks; unavailable API falls back to engine',async()=>{
 const calls=[],engine={search:async fen=>{calls.push(fen);return {best:'e2e3',cp:0,source:'engine'};}};
 const oracle=new Oracle(engine),original=global.fetch;
 const fen='8/8/8/3k4/8/2Q5/4K3/8 w - - 0 1';
 try{
  global.fetch=async()=>({ok:true,json:async()=>({category:'win',moves:[{uci:'c3b4',category:'loss'}]})});
  const first=await oracle.reply(fen);assert.equal(first.best,'c3b4');assert.equal(first.source,'tablebase');assert.equal(calls.length,0);
  global.fetch=async()=>{throw new Error('offline');};
  assert.equal((await oracle.analyse(fen)).source,'tablebase','cached positions work offline');
  assert.equal((await oracle.analyse(fen.replace(' 0 1',' 90 1'))).source,'engine');assert.equal(calls.length,1);
  assert.equal((await oracle.analyse(fen.replace(' 0 1',' 91 1'))).source,'engine');assert.equal(calls.length,2);
 }finally{global.fetch=original;}
});
test('opponent prefers queen when it preserves the same exact promotion outcome',async()=>{const o=new Oracle({});o.analyse=async()=>({category:'draw',source:'tablebase',moves:[{uci:'h7h8b',category:'draw'},{uci:'h7h8q',category:'draw'}]});assert.equal((await o.reply('unused')).best,'h7h8q');o.analyse=async()=>({category:'draw',source:'tablebase',moves:[{uci:'h7h8n',category:'draw'},{uci:'h7h8q',category:'win'}]});assert.equal((await o.reply('unused')).best,'h7h8n','avoid queen when underpromotion alone preserves the draw');});
test('uncertain tablebase categories fall back to a labeled engine estimate',async()=>{let searched=false;const o=new Oracle({search:async()=>{searched=true;return {cp:0,source:'engine'};}});o.tablebase=async()=>({category:'maybe-win',moves:[],source:'tablebase'});assert.equal((await o.analyse('unused')).source,'engine');assert.equal(searched,true);});

test('move review uses exact outcomes without engine searches when both are available',async()=>{
 const o=new Oracle({search:()=>{throw new Error('exact review must not search');}});
 const r=await o.reviewMove('8/8/8/8/8/8/8/8 w - - 0 1','8/8/8/8/8/8/8/8 b - - 0 1','w',{category:'win'},{category:'draw'});
 assert.equal(r.verdict.exact,true);assert.equal(r.verdict.mistake,true);
});
test('losing tablebase coverage triggers comparable engine searches on both sides of the move',async()=>{
 const calls=[],o=new Oracle({search:async fen=>{calls.push(fen);return {cp:500,source:'engine',best:'a1a2'};}});
 const before='before w',after='after b',r=await o.reviewMove(before,after,'w',{category:'win'},{cp:0,source:'engine'});
 assert.deepEqual(calls,[before]);assert.equal(r.verdict.exact,false);assert.equal(r.verdict.mistake,true);
 assert.equal(r.verdict.before,500);assert.equal(Math.abs(r.verdict.after),0);
});
test('entering tablebase coverage still compares estimates from the same perspective',async()=>{
 const calls=[],o=new Oracle({search:async fen=>{calls.push(fen);return {cp:500,source:'engine'};}});
 const r=await o.reviewMove('before b','after w','b',{cp:500,source:'engine'},{category:'win'});
 assert.deepEqual(calls,['after w']);assert.equal(r.verdict.mistake,true);assert.equal(r.verdict.after,-500);
});
test('missing engine scores pause a review instead of returning a false clean verdict',async()=>{
 const o=new Oracle({search:async()=>({source:'engine',best:'a1a2'})});
 await assert.rejects(o.reviewMove('before w','after b','w',{category:'win'},{source:'engine'}),/complete before-and-after/);
});
test('failed analysis can be retried on the original decision and still detects the mistake',async()=>{
 let failed=false;const calls=[],o=new Oracle({search:async fen=>{calls.push(fen);if(!failed){failed=true;throw new Error('worker interrupted');}return {cp:500,source:'engine'};}});
 const args=['before w','after b','w',{category:'win'},{cp:0,source:'engine'}];
 await assert.rejects(o.reviewMove(...args),/worker interrupted/);
 const retried=await o.reviewMove(...args);assert.equal(retried.verdict.mistake,true);assert.deepEqual(calls,['before w','before w']);
});
test('mate estimates remain comparable when one side has only an exact result',async()=>{
 const o=new Oracle({search:async()=>({mate:4,source:'engine'})});
 const r=await o.reviewMove('before w','after b','w',{category:'win'},{cp:200,source:'engine'});
 assert.equal(r.verdict.mistake,true);assert.equal(r.verdict.exact,false);
});
