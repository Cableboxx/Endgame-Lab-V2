"""Independent python-chess validation of source archives and application facts."""
import chess,chess.pgn,json,pathlib
root=pathlib.Path(__file__).resolve().parent.parent
lessons=json.loads((root/'data/curriculum.json').read_text());practice=json.loads((root/'data/practice.json').read_text())
games=[]
for name in ['curriculum.pgn','pawn-course.pgn','transfer.pgn','pawn-transfer.pgn','pawn-mistake-example.pgn']:
 with (root/'sources'/name).open() as f:
  while (g:=chess.pgn.read_game(f)) is not None:games.append(g)
records=lessons+practice+[l['mistakeExample'] for l in lessons if l.get('mistakeExample')]
plies=0;matched=0
for r in records:
 b=chess.Board(r['fen']);assert b.is_valid(),r.get('id','mistake example')
 if r in lessons+practice:assert not b.is_game_over(),r.get('id')
 expected=r.get('demonstrationLine',r.get('line',[]));moves=[]
 for step in expected:
  san=step if isinstance(step,str) else step['san'];m=b.parse_san(san);moves.append(m);b.push(m);assert b.is_valid();plies+=1
 candidates=[g for g in games if g.board().fen()==chess.Board(r['fen']).fen()]
 assert candidates,'no source archive for '+r.get('id','mistake example')
 assert any(list(g.mainline_moves())==moves for g in candidates),'source mismatch: '+r.get('id','mistake example')
 matched+=1
print(f'python-chess: {len(lessons)} lessons, {len(practice)} transfer starts, {matched} archived source records, {plies} legal source plies; all match.')
