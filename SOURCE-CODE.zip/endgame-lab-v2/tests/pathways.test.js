import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Chess} from '../assets/chess.js';
import {COURSE_TIERS,COURSE_SECTIONS,tierFor,makeExercises,nextInSection} from '../learning.js';
import {fenKey,perspective,capturedSquare,uciMove,loadProgress} from '../core.js';
import {guidedReply,preservingMoves,pressureFeatures} from '../opponent.js';
import {practiceExplanation} from '../coach.js';
const lessons=JSON.parse(readFileSync('data/curriculum.json')),practice=JSON.parse(readFileSync('data/practice.json')),cache=JSON.parse(readFileSync('data/tablebase-cache.json'));
const added=lessons.filter(l=>['practical','advanced'].includes(l.section));
test('three freely accessible tiers retain both Essential courses and all 21 new lessons',()=>{
 assert.deepEqual(COURSE_TIERS.map(t=>t.id),['essential','practical','advanced']);assert.equal(COURSE_SECTIONS.filter(c=>c.tier==='essential').length,2);assert.equal(lessons.length,43);assert.equal(added.length,21);assert.equal(makeExercises(lessons,practice).length,86);
 for(const l of lessons)assert.ok(COURSE_TIERS.some(t=>t.id===tierFor(l)));
 assert.equal(nextInSection(lessons,'queen-versus-minor'),null);assert.equal(nextInSection(lessons,'bishop-knight-coordination'),null);
});
test('new lessons have their own plans, limitations, prerequisites, source chapters and annotated legal moves',()=>{
 for(const l of added){assert.ok(l.plan.length===3&&l.limits.length>40&&l.concept.length>70);assert.ok(l.prerequisiteIds.every(id=>lessons.some(p=>p.id===id)));assert.match(l.source.url,/^https:\/\/lichess.org\/study\/\w+\/\w+$/);const c=new Chess(l.fen);for(const step of l.line){assert.ok(step.text.length>30);if(step.moveKind==='forced')assert.equal(c.moves().length,1);assert.equal(c.moves().length,step.legalMoveCount);c.move(step.san);}}
});
test('new published practice starts are unique and honestly distinguish reinforcement from transfer',()=>{
 const newPractice=practice.filter(p=>added.some(l=>l.id===p.lessonId)),seen=new Set();
 for(const p of newPractice){const l=added.find(l=>l.id===p.lessonId),k=p.fen.split(' ').slice(0,2).join(' ');assert.notEqual(k,l.fen.split(' ').slice(0,2).join(' '));assert.ok(!seen.has(k),p.id);seen.add(k);assert.equal(p.exerciseKind,p.publishedId===l.publishedId?'reinforcement':'transfer');assert.ok(p.demonstrationLine.length);assert.ok(p.hint.length>60);}
});
test('all exact expansion starts match the learner goal and larger starts retain labeled engine estimates',()=>{
 const audit=JSON.parse(readFileSync('tests/expansion-root-audit.json'));assert.equal(audit.positions.length,42);assert.equal(audit.errors.length,0);assert.ok(audit.positions.every(p=>p.matches));
 for(const p of audit.positions){if(p.exact)assert.equal(perspective(cache[fenKey(p.fen)],new Chess(p.fen).turn(),p.side),p.goal==='win'?1:0);else assert.ok(Number.isFinite(p.cp));}
});
test('source move audit detects no outcome-losing learner move in the expansion',()=>{
 const audit=JSON.parse(readFileSync('tests/expansion-move-audit.json'));assert.ok(audit.positions.length>300);assert.equal(audit.missing.length,0);assert.equal(audit.drops.length,0);
});
test('all exact defensive expansion replies remain sound and retain meaningful pressure where available',{timeout:120000},async()=>{
 let checked=0;for(const l of added.filter(l=>l.goal==='draw')){const c=new Chess(l.fen);for(const step of l.line){if(c.turn()!==l.side&&!c.isGameOver()){
 const fen=c.fen(),root=cache[fenKey(fen)];if(root){const options=preservingMoves(fen,root);assert.ok(options.length);const r=await guidedReply(fen,root,{search:async(_fen,_ms,{searchmoves})=>({best:searchmoves[0]})},{exercise:l});assert.ok(options.some(m=>m.uci===r.best));if(options.some(m=>pressureFeatures(fen,m.uci).tier===0))assert.equal(pressureFeatures(fen,r.best).tier,0);checked++;}}
 c.move(step.san);}}
 assert.ok(checked>45);
});
test('en passant explanations identify the captured pawn square rather than the arrival square',()=>{
 const l=lessons.find(l=>l.id==='two-weaknesses'),c=new Chess('6k1/5p2/r3p1p1/3p1n2/3P2Pp/1P1R3P/4NP2/6K1 b - g3 0 37');const beforeFen=c.fen(),move=c.move('hxg3');assert.equal(capturedSquare(move),'g4');const altered={...l,demonstrationLine:[]};const r=practiceExplanation({exercise:altered,beforeFen,move,fen:c.fen()});assert.match(r.text,/pawn from g4/);
});
test('older browser progress keys remain unchanged as the curriculum expands',()=>{
 const data={'queen-box':{seen:true,passed:true},'majority-lever':{independentSuccesses:1}};assert.deepEqual(loadProgress({getItem:k=>{assert.equal(k,'endgame-lab-v2');return JSON.stringify(data);}}),data);
});
