import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {Chess} from '../assets/chess.js';
import {fenKey,uciMove} from '../core.js';
import {makeExercises} from '../learning.js';
import {sourceMoveNote,passedPawns,positionInsight,practiceExplanation,breakthroughBranches} from '../coach.js';
import {lessonPieces,coursePieces} from '../presentation.js';
const lessons=JSON.parse(readFileSync('data/curriculum.json'));
const exercises=makeExercises(lessons,JSON.parse(readFileSync('data/practice.json')));
const cache=JSON.parse(readFileSync('data/tablebase-cache.json'));
const screenshot='8/6pp/6pP/5P2/8/1k6/8/K7 w - - 0 1';
test('screenshot breakthrough explanation replays both captures and verifies the surviving passed pawns',()=>{
 const r=breakthroughBranches(screenshot,{best:'f5g6',source:'engine'},'w');assert.ok(r);assert.equal(r.move,'fxg6');assert.equal(r.branches.length,2);
 for(const branch of r.branches){const c=new Chess(screenshot);branch.line.forEach(m=>c.move(uciMove(m)));assert.ok(passedPawns(c,'w').some(p=>p.square===c.history({verbose:true}).at(-1).to));}
 assert.match(r.text,/gxh6/);assert.match(r.text,/hxg6/);assert.match(r.text,/not forced/);
});
test('breakthrough examples are never generated from a result-losing candidate',()=>{
 assert.equal(breakthroughBranches(screenshot,{category:'win',moves:[{uci:'f5g6',category:'draw'}]},'w'),null);
});
test('source explanations require both the actual position and the actual move',()=>{
 const l=lessons.find(l=>l.id==='connected-passers');assert.match(sourceMoveNote(l,l.fen,'h5h6'),/Rg6 protects/);
 assert.equal(sourceMoveNote(l,l.fen,'a2a3'),null);
 const changed=l.fen.replace('6R1','5R2');assert.equal(sourceMoveNote(l,changed,'h5h6'),null);
});
test('mixed practice does not reveal the technique through automatic coaching',()=>{
 const l=lessons[0],c=new Chess(l.fen),m=c.move('Qb4');assert.equal(practiceExplanation({exercise:l,beforeFen:l.fen,move:m,fen:c.fen(),masked:true}),null);
});
test('rook on g7 is never reported as defending the queen on h8',()=>{
 const fen='7Q/6R1/5kP1/8/8/8/K7/7r b - - 0 6',r=positionInsight(fen,lessons.find(l=>l.id==='connected-passers'));
 assert.ok(!r?.claims?.some(c=>c.from==='g7'&&c.to==='h8'));
});
test('knight-file pawn lesson uses a pawn icon rather than a misleading knight',()=>{
 assert.deepEqual(lessonPieces({id:'knight-pawn'}).map(p=>p.type),['k','p']);assert.deepEqual(lessonPieces({id:'queen-box'}).map(p=>p.type),['q']);
});
test('every lesson and practice icon resolves to the exact board SVG family',()=>{
 for(const l of exercises)for(const p of lessonPieces(l)){assert.equal(p.color,'w');assert.ok(existsSync(`assets/pieces/${p.color}${p.type.toUpperCase()}.svg`));}
 assert.deepEqual(coursePieces('pawn-play').map(p=>p.type),['p','p']);
});
for(const l of exercises)test('practice coaching follows legal published positions: '+l.id,()=>{
 const c=new Chess(l.fen);let count=0;const published=l.demonstrationLine||l.line||[],sequence=published.length?published:[c.moves()[0]];
 for(const step of sequence){
  const beforeFen=c.fen(),turn=c.turn(),m=c.move(typeof step==='string'?step:step.san);if(turn!==l.side||c.isGameOver())continue;
  const afterFen=c.fen(),next=sequence[c.history().length];let opponent;
  const shown=new Chess(afterFen);
  if(next){const b=shown.fen(),reply=shown.move(typeof next==='string'?next:next.san);opponent={beforeFen:b,uci:reply.from+reply.to+(reply.promotion||'')};}
  const explanation=practiceExplanation({exercise:l,beforeFen,move:m,fen:shown.fen(),analysis:cache[fenKey(shown.fen())],opponent});
  assert.ok(explanation.text.length>30,l.id+' '+m.san);count++;
  for(const claim of explanation.claims){if(claim.type==='attack')assert.ok(shown.attackers(claim.to,claim.side).includes(claim.from));if(claim.type==='passed')assert.ok(passedPawns(shown,l.side).some(p=>p.square===claim.square));}
 }
 assert.ok(count>0);
});
test('promotion feedback retains the requirement to finish the conversion',()=>{
 const l=lessons.find(l=>l.id==='opposition'),c=new Chess(l.fen);for(const step of l.line){const beforeFen=c.fen(),m=c.move(step.san);if(m.promotion){const r=practiceExplanation({exercise:l,beforeFen,move:m,fen:c.fen()});assert.match(r.text,/promotion|queen|conver/i);assert.equal(c.isGameOver(),false);}}
});
test('screenshot can also explain the direct hxg7 breakthrough rather than insisting on one recipe',()=>{
 const r=positionInsight(screenshot,{id:'pawn-breakthrough',side:'w'},{best:'h6g7',source:'engine'});assert.equal(r.kind,'breakthrough-capture');assert.match(r.text,/hxg7/);const c=new Chess(screenshot);c.move(uciMove(r.continuation));assert.ok(passedPawns(c,'w').some(p=>p.square==='g7'));
});
test('opponent king explanation identifies a genuinely new legal entry square',()=>{
 const l=lessons.find(l=>l.id==='opposition'),c=new Chess(l.fen),beforeFen=c.fen(),m=c.move('Kd5'),replyFen=c.fen();c.move('Ke7');
 const r=practiceExplanation({exercise:l,beforeFen,move:m,fen:c.fen(),opponent:{beforeFen:replyFen,uci:'d7e7'}});assert.match(r.response,/c6/);assert.equal(new Chess(replyFen).isAttacked('c6','b'),true);assert.equal(c.isAttacked('c6','b'),false);assert.ok(c.moves().includes('Kc6'));
});
test('off-source promotion summary explains the new piece instead of an unrelated protected pawn',()=>{
 const l=lessons.find(l=>l.id==='passer-versus-knight'),c=new Chess(l.fen);for(const step of l.line){const beforeFen=c.fen(),m=c.move(step.san);if(m.promotion){const r=practiceExplanation({exercise:{...l,demonstrationLine:[]},beforeFen,move:m,fen:c.fen()});assert.match(r.summary,/queen/);assert.match(r.summary,/conversion/);}}
});
