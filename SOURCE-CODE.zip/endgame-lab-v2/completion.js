import {terminal,perspective} from './core.js';
// Curriculum-wide completion: all current winning exercises require checkmate.
// A move-level achievement is feedback only, never a completed attempt.
export function exerciseResult(chess,exercise){return terminal(chess,exercise.side,exercise.goal);}
export function instructionalMilestone(move,analysis,chess,exercise,userMoves){
 if(move.promotion){const value=perspective(analysis,chess.turn(),exercise.side);return {title:'Promotion achieved — keep playing.',text:value===1?'The position is still winning. Promotion is a milestone; complete the conversion to checkmate.':value===0?'The promotion has not produced a win. The position is drawn with accurate play.':'Promotion alone does not settle the result. Continue playing and keep the new piece safe.'};}
 if(exercise.goal==='draw'&&userMoves===20&&perspective(analysis,chess.turn(),exercise.side)===0)return {title:'Twenty moves defended.',text:'The position remains drawn. This is a milestone, not exercise completion; keep defending until the game ends in a draw.'};
 return null;
}
