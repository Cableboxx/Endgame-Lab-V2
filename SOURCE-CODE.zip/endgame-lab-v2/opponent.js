import {Chess} from './assets/chess.js';
import {categoryValue,uciMove} from './core.js';
const boardKey=fen=>fen.split(' ').slice(0,4).join(' ');
const material={p:100,n:320,b:330,r:500,q:900,k:0};
const distance=(a,b)=>Math.max(Math.abs(a.charCodeAt(0)-b.charCodeAt(0)),Math.abs(Number(a[1])-Number(b[1])));
export function sourceReply(fen,exercise){
 if(!exercise)return null;
 const c=new Chess(exercise.fen),target=boardKey(fen),fullmove=Number(fen.split(' ')[5]),matches=[];
 for(const step of exercise.demonstrationLine||exercise.line||[]){
  const at=c.fen(),m=c.move(typeof step==='string'?step:step.san);
  if(boardKey(at)===target)matches.push({uci:m.from+m.to+(m.promotion||''),distance:Math.abs(Number(at.split(' ')[5])-fullmove),exact:at===fen});
 }
 matches.sort((a,b)=>Number(b.exact)-Number(a.exact)||a.distance-b.distance);
 return matches[0]?.uci||null;
}
export function preservingMoves(fen,result){
 const value=categoryValue(result?.category);if(value===null)return [];
 const c=new Chess(fen),legal=new Set(c.moves({verbose:true}).map(m=>m.from+m.to+(m.promotion||'')));
 return (result.moves||[]).filter(m=>legal.has(m.uci)&&categoryValue(m.category)===-value);
}
export function pressureFeatures(fen,uci,history=[]){
 const after=new Chess(fen),side=after.turn(),move=after.move(uciMove(uci));
 const drawNow=after.isDraw(),mateNow=after.isCheckmate();
 let instantDrawReply=false,freeMaterial=0;
 if(!drawNow&&!mateNow){
  for(const reply of after.moves({verbose:true})){
   // Actual legal replies, not attack assumptions, determine whether a sacrifice trivializes the task.
   const child=new Chess(after.fen());child.move(reply);
   if(child.isDraw())instantDrawReply=true;
   if(reply.captured)freeMaterial=Math.max(freeMaterial,material[reply.captured]||0);
  }
 }
 const pawns=after.board().flat().filter(p=>p?.color===side&&p.type==='p');
 const advanced=pawns.reduce((n,p)=>Math.max(n,side==='w'?Number(p.square[1]):9-Number(p.square[1])),0);
 const king=after.board().flat().find(p=>p?.color===side&&p.type==='k');
 const kingNear=pawns.length&&king?8-Math.min(...pawns.map(p=>distance(king.square,p.square))):0;
 const repeats=history.filter(f=>boardKey(f)===boardKey(after.fen())).length;
 const tier=drawNow||instantDrawReply?1:0;
 const score=(mateNow?100000:0)+(move.promotion==='q'?20:0)+(move.piece==='p'?35:0)+advanced*3+kingNear*2-(freeMaterial/30)-repeats*45;
 return {uci,move,afterFen:after.fen(),tier,score,drawNow,instantDrawReply,freeMaterial,repeats};
}
export async function guidedReply(fen,result,engine,{exercise,history=[]}={}){
 const sound=preservingMoves(fen,result);if(!sound.length)return engine.search(fen);
 // Only rank objectively result-preserving moves; sacrifices remain legal and can be necessary.
 const ranked=sound.map(m=>({...pressureFeatures(fen,m.uci,history),tablebaseMove:m}));
 const bestTier=Math.min(...ranked.map(m=>m.tier));let pool=ranked.filter(m=>m.tier===bestTier);
 if(pool.some(m=>m.repeats<2))pool=pool.filter(m=>m.repeats<2);
 const published=sourceReply(fen,exercise),source=pool.find(m=>m.uci===published);
 if(source)return {...result,best:source.uci,policy:'guided',selection:'source-preserving'};
 // Prefer sound moves that retain pressure. Let Stockfish choose between comparably instructive options.
 const top=Math.max(...pool.map(m=>m.score));pool=pool.filter(m=>m.score>=top-15);
 if(pool.length===1)return {...result,best:pool[0].uci,policy:'guided',selection:'pressure-preserving'};
 const searched=await engine.search(fen,500,{searchmoves:pool.map(m=>m.uci)});
 const chosen=pool.find(m=>m.uci===searched.best)||pool.sort((a,b)=>b.score-a.score)[0];
 return {...result,best:chosen.uci,policy:'guided',selection:'engine-among-preserving'};
}
