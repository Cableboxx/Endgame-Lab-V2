import {Chess} from './assets/chess.js';
import {categoryValue,uciMove} from './core.js';
const key=fen=>fen.split(' ').slice(0,4).join(' ');
const names={p:'pawn',n:'knight',b:'bishop',r:'rook',q:'queen',k:'king'};
const label=side=>side==='w'?'White':'Black';
const pieces=c=>c.board().flat().filter(Boolean);
const distance=(a,b)=>Math.max(Math.abs(a.charCodeAt(0)-b.charCodeAt(0)),Math.abs(Number(a[1])-Number(b[1])));
export function passedPawns(c,side){return pieces(c).filter(p=>p.color===side&&p.type==='p'&&!pieces(c).some(q=>q.color!==side&&q.type==='p'&&Math.abs(q.square.charCodeAt(0)-p.square.charCodeAt(0))<=1&&(side==='w'?q.square[1]>p.square[1]:q.square[1]<p.square[1])));}
export function sourceMoveNote(exercise,fen,uci){
 const c=new Chess(exercise.fen),matches=[];
 for(const step of exercise.demonstrationLine||exercise.line||[]){const before=c.fen(),m=c.move(typeof step==='string'?step:step.san);if(key(before)===key(fen)&&m.from+m.to+(m.promotion||'')===uci&&(step.text||step.note))matches.push({text:step.text||step.note,offset:Math.abs(Number(before.split(' ')[5])-Number(fen.split(' ')[5]))});}
 return matches.sort((a,b)=>a.offset-b.offset)[0]?.text||null;
}
// Describe only branches that can be legally replayed and actually produce a passed pawn.
// A branch is an illustration, never a claim that the opponent must capture.
export function breakthroughBranches(fen,analysis,side){
 const c=new Chess(fen);if(c.turn()!==side||c.isCheck())return null;
 const v=categoryValue(analysis?.category),allowed=v===null?[]:(analysis.moves||[]).filter(m=>categoryValue(m.category)===-v).map(m=>m.uci);
 if(!allowed.length&&analysis?.best)allowed.push(analysis.best);
 for(const uci of allowed){
  const after=new Chess(fen);let offer;try{offer=after.move(uciMove(uci));}catch{continue;}
  if(offer.piece!=='p'||!offer.captured||offer.promotion)continue;
  const branches=[];
  for(const capture of after.moves({verbose:true}).filter(m=>m.piece==='p'&&m.captured==='p')){
   const b=new Chess(after.fen());b.move(capture);
   const push=b.moves({verbose:true}).find(m=>{if(m.piece!=='p'||m.captured||m.promotion)return false;const next=new Chess(b.fen());next.move(m);return passedPawns(next,side).some(p=>p.square===m.to);});
   if(push)branches.push({capture:capture.san,push:push.san,runner:push.from,line:[uci,capture.from+capture.to,push.from+push.to]});
  }
  if(branches.length>=2&&new Set(branches.map(b=>b.runner)).size>=2)return {move:offer.san,branches:branches.slice(0,2),text:`${offer.san} can pull apart the pawn blockade: after …${branches[0].capture}, ${branches[0].push} advances a passed pawn; after …${branches[1].capture}, ${branches[1].push} advances the other. Capturing one pawn clears the route for its partner. These are capture examples, not forced replies.`};
 }
 return null;
}
export function positionInsight(fen,exercise,analysis){
 const c=new Chess(fen),side=exercise.side,all=pieces(c),enemy=side==='w'?'b':'w',own=all.filter(p=>p.color===side),king=own.find(p=>p.type==='k'),enemyKing=all.find(p=>p.color===enemy&&p.type==='k');
 if(c.isGameOver())return null;
 const id=exercise.lessonId||exercise.id;
 if(id==='pawn-breakthrough'&&c.turn()===side){
  const value=categoryValue(analysis?.category),candidates=value===null?(analysis?.best?[analysis.best]:[]):(analysis.moves||[]).filter(m=>categoryValue(m.category)===-value).map(m=>m.uci);
  for(const candidate of candidates){const b=new Chess(fen);let capture;try{capture=b.move(uciMove(candidate));}catch{continue;}
   if(capture.piece==='p'&&capture.captured&&passedPawns(b,side).some(p=>p.square===capture.to)){
    const promotion=capture.to[0]+(side==='w'?'8':'1'),oneStep=Number(capture.to[1])===(side==='w'?7:2);
    const kingTooFar=oneStep&&enemyKing&&distance(enemyKing.square,capture.to)>1&&distance(enemyKing.square,promotion)>1;
    return {text:`The advance has opened a breakthrough: ${capture.san} removes the pawn on ${capture.to} and leaves a passed pawn there. No enemy pawn remains ahead on its file or either neighboring file.${kingTooFar?` The king on ${enemyKing.square} cannot reach either ${capture.to} or ${promotion} in one move, so that king alone cannot stop the next pawn advance.`:''} The pawn offers remove blockers to free a runner, rather than keep every pawn.`,kind:'breakthrough-capture',continuation:candidate};
   }
  }
  const branch=breakthroughBranches(fen,analysis,side);if(branch)return {text:branch.text,kind:'breakthrough',branches:branch};
 }

 const runners=passedPawns(c,side).sort((a,b)=>(side==='w'?Number(b.square[1])-Number(a.square[1]):Number(a.square[1])-Number(b.square[1])));
 for(const pawn of runners){
  const support=c.attackers(pawn.square,side).filter(s=>s!==pawn.square);
  const advanced=side==='w'?Number(pawn.square[1]):9-Number(pawn.square[1]);
  if(advanced>=5){
   const promotion=pawn.square[0]+(side==='w'?'8':'1'),blockers=all.filter(p=>p.square[0]===pawn.square[0]&&(side==='w'?p.square[1]>pawn.square[1]:p.square[1]<pawn.square[1]));
   const lead=`The pawn on ${pawn.square} is passed: no enemy pawn is ahead on its file or either neighboring file.`;
   const tail=blockers.length?` The ${names[blockers[0].type]} on ${blockers[0].square} still occupies its route to ${promotion}; being passed does not mean it can advance freely.`:support.length?` Your ${names[c.get(support[0]).type]} on ${support[0]} protects it. Keep that support as you work toward ${promotion}.`:` Its route toward ${promotion} has no piece in front, but check the enemy king and rook before pushing; a passed pawn is not automatically unstoppable.`;
   return {text:lead+tail,kind:'passed-pawn',claims:[{type:'passed',square:pawn.square},...support.slice(0,1).map(from=>({type:'attack',from,to:pawn.square,side}))]};
  }
 }
 const pawns=all.filter(p=>p.type==='p');
 if(king&&enemyKing&&pawns.length===1){
  const sameFile=king.square[0]===enemyKing.square[0],sameRank=king.square[1]===enemyKing.square[1],d=distance(king.square,enemyKing.square);
  if((sameFile||sameRank)&&d===2){const holder=c.turn()===side?enemyKing:king;return {text:`The kings on ${king.square} and ${enemyKing.square} have one square between them. ${label(holder.color)} holds the direct opposition because the other side must move. ${exercise.goal==='draw'?'Use that spacing to deny the attacking king a route around your blockade.':'Use the king to win entry beside the pawn; moving the pawn too soon can give up useful waiting moves.'}`,kind:'opposition'};}
 }
 if(id==='wrong-bishop'){
  const pawn=all.find(p=>p.color===enemy&&p.type==='p'),bishop=all.find(p=>p.color===enemy&&p.type==='b');
  if(pawn&&bishop&&['a','h'].includes(pawn.square[0])){const square=pawn.square[0]+(enemy==='w'?'8':'1');if(c.squareColor(square)!==c.squareColor(bishop.square))return {text:`The bishop on ${bishop.square} is on ${c.squareColor(bishop.square)} squares; the pawn promotes on the ${c.squareColor(square)} square ${square}. That bishop can never attack the promotion corner. Keep your king able to return there instead of chasing material.`,kind:'fortress'};}
 }
 const rook=own.find(p=>p.type==='r'),pawn=all.find(p=>p.type==='p');
 if(rook&&pawn){
  const behind=rook.square[0]===pawn.square[0]&&(pawn.color==='w'?rook.square[1]<pawn.square[1]:rook.square[1]>pawn.square[1]);
  if(behind)return {text:`Your rook on ${rook.square} is behind the pawn on ${pawn.square}. ${pawn.color===side?'As the pawn advances, the rook has room to keep supporting it from behind.':'That keeps the rook aligned with the pawn’s advance, making the opponent keep it protected.'} Check intervening pieces before assuming the rook already attacks or defends the pawn.`,kind:'rook-behind'};
 }
 if(king&&pawns.length){
  const supported=pawns.find(p=>p.color===side&&c.attackers(p.square,side).includes(king.square));
  if(supported)return {text:`Your king on ${king.square} protects the pawn on ${supported.square}. That gives the pawn direct support, but the king must also control its route forward; advancing just because it is protected can still let the defender blockade it.`,kind:'king-support',claims:[{type:'attack',from:king.square,to:supported.square,side}]};
 }
 return null;
}
export function practiceExplanation({exercise,beforeFen,move,fen,analysis,opponent,masked=false}){
 if(masked)return null;
 const before=new Chess(beforeFen),after=new Chess(beforeFen);const played=after.move(typeof move==='string'?uciMove(move):move);
 const uci=played.from+played.to+(played.promotion||''),annotation=sourceMoveNote(exercise,beforeFen,uci);
 let action=annotation;if(action&&played.promotion)action+=' Promotion is a milestone; keep the new piece safe and finish the conversion to checkmate.';
 if(!action){
  if(played.promotion)action=`${played.san} creates a ${names[played.promotion]}, but promotion is only a milestone. Keep the new piece safe and finish the conversion.`;
  else if(played.captured)action=`${played.san} removes ${label(played.color==='w'?'b':'w')}’s ${names[played.captured]} from ${played.to}${after.isCheck()?' with check':''}. The value of the exchange depends on the position left behind, not just the material count.`;
  else if(played.piece==='p'){
   const defenders=after.attackers(played.to,played.color),becamePassed=passedPawns(after,played.color).some(p=>p.square===played.to)&&!passedPawns(before,played.color).some(p=>p.square===played.from);
   action=`${played.san} ${becamePassed?'creates a passed pawn by moving beyond the enemy pawn front':`advances the pawn from ${played.from} to ${played.to}`}.${defenders.length?` It is protected there by your ${names[after.get(defenders[0]).type]} on ${defenders[0]}.`:' Check its safety before advancing it again.'}`;
  }else if(after.isCheck())action=`${played.san} gives check, so the opponent must answer the attack on the king before continuing their plan.`;
  else if(played.piece==='k'){
   const targets=pieces(before).filter(p=>p.type==='p'),closer=targets.find(p=>distance(played.to,p.square)<distance(played.from,p.square));
   action=closer?`${played.san} brings your king closer to the pawn on ${closer.square}. King activity matters because it can support an advance or attack a blocker without spending a pawn move.`:`${played.san} changes the king’s position without committing a pawn. Compare the new king spacing and entry squares before choosing your next move.`;
  }else if(['q','r'].includes(played.piece)&&pieces(after).filter(p=>p.color!==played.color).every(p=>p.type==='k')){const enemyKing=pieces(after).find(p=>p.color!==played.color&&p.type==='k'),escapes=after.moves({square:enemyKing.square}).length;action=`After ${played.san}, the opposing king on ${enemyKing.square} has ${escapes} legal king move${escapes===1?'':'s'}. Use your ${names[played.piece]} to limit its space while your king comes closer; leave a legal reply until you can deliver mate.`;}
  else action=`${played.san} repositions your ${names[played.piece]} from ${played.from} to ${played.to}. ${exercise.concept||exercise.principle||'Coordinate it with your king before committing to the next stage.'}`;
 }
 let response=null;if(opponent){const b=new Chess(opponent.beforeFen),m=b.move(uciMove(opponent.uci));response=sourceMoveNote(exercise,opponent.beforeFen,opponent.uci);if(!response&&m.captured)response=`${m.san} captures your ${names[m.captured]} on ${m.to}. Reassess the remaining pawn routes and piece safety.`;else if(!response&&b.isCheck())response=`${m.san} gives check. Answer it while keeping the endgame plan in view.`;
 if(!response&&m.piece==='k'){
  const ownKing=pieces(b).find(p=>p.color===exercise.side&&p.type==='k');
  const entry=ownKing&&b.moves({square:ownKing.square,verbose:true}).find(r=>(exercise.side==='w'?r.to[1]>r.from[1]:r.to[1]<r.from[1])&&new Chess(opponent.beforeFen).isAttacked(r.to,m.color)&&!b.isAttacked(r.to,m.color));
  if(entry)response=`${m.san} changes the king’s control: ${entry.to} was attacked before that reply, but is no longer attacked. Your king can now legally enter with ${entry.san}. Compare that entry with the pawn’s route before deciding.`;
 }
 }
 const insight=positionInsight(fen,exercise,analysis);
 return {text:action,summary:annotation?action:insight?.text||action,position:insight?.text||null,response,kind:insight?.kind||'move',claims:insight?.claims||[]};
}
