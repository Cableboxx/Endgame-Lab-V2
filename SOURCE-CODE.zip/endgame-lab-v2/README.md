# Endgame Lab V3.0 — learning pathways

A complete static chess trainer for GitHub Pages. The original Endgame Lab site is untouched. Upload this release to the **existing V2 repository**, using the same URL to preserve browser-local progress.

## Three tiers, freely accessible

| Tier | Courses | Lessons |
| --- | --- | --- |
| Essential Endgames | Essential techniques; Create the passed pawn | 22 |
| Practical Endgames | Practical endgame decisions | 10 |
| Advanced Endgames | Advanced calculation and conversion | 11 |

There are **43 lessons and 86 practice starts**: one lesson start and one additional published start per lesson. The extra starts comprise 37 transfer positions from other source chapters and six explicitly labeled reinforcement positions later in the same chapter. They are not mirrored or randomly generated diagrams.

Practical covers king activity, pawn restraint, knight circuits, bishop blockades, defensive exchanges, a passer against a knight, rook-pawn geometry, short checking distance, and queen/minor-piece coordination. Advanced covers mutual zugzwang, the Reti dual-purpose king route, promotion checks and skewers, queen-versus-pawn exceptions, Vancura, the importance of a second pawn's file, active rook counterplay, and strategic conversion from Capablanca–Lasker. Bishop-and-knight mate is an optional final technical capstone.

Difficulty is a recommended progression, not a lock. Mixed practice initially stays within Essential; choose another tier or All tiers in Practice. Reviews can include all tiers.

## Learning and evaluation

- Demonstrations are uninterrupted, with original move-by-move course explanations and exact source links. Every expansion move is annotated; forced labels are checked against the legal move count.
- Practice uses source explanations only for a matching position and move. Off-source feedback uses verified board facts, with expandable move/reply details.
- Winning exercises continue to actual checkmate. Promotion, material gains and defensive move counts are milestones only. Drawing exercises require an actual game draw.
- Guided defense filters legal Syzygy result-preserving moves, then prefers meaningful pressure and source continuations. Necessary sacrifices remain allowed. Free play uses unrestricted Stockfish and awards no guided credit.
- Up to seven pieces: cached/live tablebase results, including fifty-move-aware categories. Larger positions: explicitly labeled Stockfish estimates. The Capablanca lesson begins later in the published game, after a clear advantage has been established; no tablebase proof is claimed for that complex position.
- Before/after review compares compatible analysis. An interrupted review remains pending until recovered. Large engine estimates that both remain decisive are not penalized solely for a change from, for example, +11 to +8; exact outcome changes are always detected without this bounding.
- Capture feedback handles en passant's captured square correctly.

## Navigation and visual consistency

The final demonstration forward button stays disabled, including in the phone dock. It never changes into Next lesson under a tapping finger. Next lesson remains available in a separate navigation area. Lesson, course and review icons use the board's Cburnett SVG family.

## Progress

The `endgame-lab-v2` storage key and all original IDs remain unchanged. Earlier completions, assisted/independent successes, hints, retries, refutations, spaced review and v1/v2 backups are preserved. Completing a position does not certify mastery of a whole subject. Back up progress from Settings before clearing browser data or changing devices.

## iPhone upload

Extract the **outer ZIP once** and upload its flat contents to the root of the existing V2 repository, replacing matching files. Keep the current Pages branch/root settings. Leave `SOURCE-CODE.zip` zipped.

The runtime consists of `index.html`, `stockfish-18-lite-single.js`, and `stockfish-18-lite-single.wasm`. Other files contain instructions, validation, source and licenses. No nested asset folders need to be recreated for the phone edition.

## Developer setup

Use Node 22 or newer:

```sh
npm ci
npm test
npm run build
npm run build:iphone
```

`npm ci` restores the matching pinned chess.js and Stockfish assets, including the binary omitted from the inner source ZIP. The outer phone ZIP includes the ready-to-host binary. `dist/` is the multi-file static site; `phone-dist/` is the flat phone edition. A GitHub Pages workflow is included for the developer source edition.

Independent source verification requires python-chess:

```sh
python3 -m pip install python-chess
npm run verify
```

No build service, account system, paid API or external font is required. Exact uncached analysis needs the Lichess tablebase service; engine and lesson assets are hosted alongside the app.

## Source and validation

The expansion uses 36 exact published chapters in NoseKnowsAll's Intermediate, More, Advanced and Rook Endgames studies. `sources/expansion-published.pgn` contains their published move facts without redistributing their instructional annotations. The separate lesson/practice PGNs record exact excerpts and source ply offsets. The independent validator compares both levels.

The project includes **273 passing tests**, legal-source replay, exact/estimated outcome reports, a learner-move audit and defensive pressure checks. See `VALIDATION.md` for the scope and practical limits. Physical iPhone/Safari testing was not available.

Rules: chess.js 1.4.0. Engine: Stockfish.js 18 lite single-thread. Pieces: Cburnett. See `THIRD_PARTY.md` and the accompanying license files. Endgame Lab code is GPL-3.0-or-later.
