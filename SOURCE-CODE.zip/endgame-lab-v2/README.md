# Endgame Lab V2.2

A complete static training website for understanding endgames and creating passed pawns. The original V1 website is untouched. This release preserves V2 lesson IDs and local progress while replacing the small course landing page with two substantial learning sections.

## Upload from iPhone

Use the supplied flat iPhone package. Extract the outer ZIP once and upload its files together to the root of the **existing V2 repository**, replacing matching names. Keep the current GitHub Pages branch/root settings. The only required runtime files are `index.html`, `stockfish-18-lite-single.js`, and `stockfish-18-lite-single.wasm`.

The inner `SOURCE-CODE.zip` contains this developer project and can stay zipped in the upload. No folders need to be recreated for the phone edition. See `IPHONE-UPLOAD.txt` for the full procedure.

## V2.2 update

- Demonstration forward controls remain disabled at the final move, including the fixed phone dock. They never turn into a different navigation action. Next lesson remains freely available in a separate Browse lessons area; there is no completion gate.
- Lesson, practice and review icons use the same Cburnett SVG assets as the board. The queen/rook/two-rook/bishop/pawn subjects are explicit; a knight-file pawn is not represented by a knight.
- Practice uses source explanations only when the position and move both match. Other continuations receive legal, board-based explanations of captures, passed pawns, support, king entries, opposition, fortresses and mating space. The screenshot breakthrough has verified alternate capture branches and direct-passer recognition.
- The main feedback explains the move or current opportunity. Move and reply explained expands the previous move, a verified reply explanation when available, and the current position. Mixed practice keeps coaching hidden until the topic is revealed.
- All V2.1 curriculum, full-game completion, defensive pressure, backups and local progress are preserved.

## The release

- **Core endgame techniques:** the existing 16 lessons, preserving all source positions, moves and IDs, with all 273 move notes reviewed and rewritten.
- **Create the passed pawn:** six lessons on a prepared two-to-one majority, king support, the three-versus-three breakthrough, outside-passer decoys, separated passers and protected passers. Includes conditions and limitations rather than presenting a slogan as universal advice.
- **44 sourced practice positions:** 22 lesson starts and 22 distinct published transfer positions. Mixed practice hides the topic; filters select course, technique and review status.
- Uninterrupted, fully replayable demonstrations, a next-lesson button at their ends and practice results, plus an optional published automatic-recapture comparison in the majority lesson.
- Practice mistakes pause for reflection. Replay a short verified/calculated consequence without changing the game, then retry the original decision or continue from it.
- Separate assisted and independent success. Hints, errors, retries, topic reveals and refutation replays prevent independent credit for that attempt. Earlier completions remain visible without being silently relabeled.
- Spaced review after independent repetitions and backward-compatible, non-destructive progress imports.
- Mobile control dock, blue board, locally bundled piece assets and engine, optional quiet sounds. No trackers, subscriptions or accounts.

## Completion rules

All current winning exercises require **actual checkmate**. Promotion, material gains, opposition and maneuver completion are feedback milestones only. The board remains playable after promotion, including after a promotion that loses the win. There is no generic material/evaluation/promotion shortcut for completion.

Defensive exercises require an actual game draw: stalemate, repetition, insufficient material or the fifty-move rule. A twenty-move hold is a milestone only. The app automatically adjudicates claimable repetition/fifty-move draws as a training policy.

`completion.js` implements this across every lesson and transfer position. No curriculum entry in this release enables an alternative completion rule.

## Guided resistance versus free play

`opponent.js` implements the guided defensive policy. It first filters legal moves using Syzygy to retain the best exact outcome. Within that set it avoids immediate trivial draws and moves that allow an immediate drawing response whenever meaningful alternatives exist. It then favors a legal, result-preserving published reply, or ranks remaining pressure-preserving choices and asks Stockfish to choose among them. Repeated source positions are matched to the right stage of the variation rather than blindly repeating the first occurrence.

Sacrifices are not universally banned. When meaningful resistance is exhausted, a source-supported necessary sacrifice or stalemate remains possible. All ranking is within exact preserving outcomes. With no exact result available, the app uses an explicitly labeled engine estimate rather than pretending to know a theoretical result.

**Free engine play** bypasses the guided selector completely: the opponent is unrestricted Stockfish. It uses the same legal board and analysis feedback but does not award guided exercise completion credit. Choose the opponent mode in the practice catalog.

## Source and claim verification

All 349 demonstration moves and 232 transfer continuation moves are published facts. The optional published six-ply mistake example brings the independent source-archive replay to 587 plies. Chapter links, source snapshots and provenance records are included. Community-authored studies are identified as such.

Core material: NoseKnowsAll's studies and official Lichess Practice. Pawn material: primarily Dr Dave Regis / Devon Junior Chess Association instructional material, with individual additional exercise authors credited. Natural-language explanations are original, and forced-move labels are checked against actual legal-move counts. Explicit attack-map assertions cover concrete protection claims, including the fact that a rook on g7 does not attack h8 and that a white h7-pawn does not protect g6.

Source variations are distinct from live calculated refutations. Each replay states which it is. Engine estimates are not tablebase proofs.

## Develop, test and build

This source archive omits the large vendored WASM binary because the phone package already includes it. The pinned dependencies restore it automatically:

```sh
npm ci
npm test
npm run build
npm run build:iphone
```

The `postinstall` script restores exact chess.js and Stockfish assets. The normal static site is in `dist/`; the flat phone edition is in `phone-dist/`. The latter bundles course data, styles, pieces and application code into `index.html`, with matching worker JS/WASM beside it.

Serve a build over HTTP, for example `python3 -m http.server 8080 --directory dist`. Do not use `file://` for Web Workers and module imports.

For the independent rules/source check:

```sh
python3 -m pip install python-chess
python3 tests/validate.py
```

See `VALIDATION.md` for exact coverage and limits. GPL-3.0-or-later; separately licensed dependencies and assets are documented in `THIRD_PARTY.md`.

### Analysis recovery

Move feedback compares exact outcomes when available on both sides. If coverage changes, it obtains comparable Stockfish estimates instead. An interrupted review stays pending: Retry analysis evaluates that original decision before allowing the opponent to continue.
