import {Chess} from './assets/chess.js';
import {uciMove,categoryValue,terminal,capturedSquare} from './core.js';
export const COURSE_TIERS=[
 {id:'essential',title:'Essential Endgames',subtitle:'Build reliable technique',description:'The complete original collection: essential conversions, defensive methods, and creating passed pawns.'},
 {id:'practical',title:'Practical Endgames',subtitle:'Choose the right plan',description:'Apply your foundations when activity, pawn structure and exchanges compete for your attention.'},
 {id:'advanced',title:'Advanced Endgames',subtitle:'Calculate the exceptions',description:'Deeper pawn races, queen exceptions, difficult rook defenses, strategic conversion and an optional technical capstone.'}
];
export const COURSE_SECTIONS=[
 {id:'core',tier:'essential',title:'Essential endgame techniques',subtitle:'Finish the advantage',description:'Mating patterns, king-and-pawn technique, fortresses, and the essential rook endings.'},
 {id:'pawn-play',tier:'essential',title:'Create the passed pawn',subtitle:'Build the advantage',description:'Learn how pawn majorities, breakthroughs, king support and decoys create promotion threats.'},
 {id:'practical',tier:'practical',title:'Practical endgame decisions',subtitle:'Apply the foundations',description:'King activity, pawn restraint, minor-piece defenses, exchanges, and rook decisions in published positions.'},
 {id:'advanced',tier:'advanced',title:'Advanced calculation and conversion',subtitle:'Understand the exceptions',description:'Pawn races, queen-versus-pawn exceptions, Vancura defense, rook counterplay, and strategic conversion.'}
];
export const tierFor=lesson=>COURSE_SECTIONS.find(c=>c.id===(lesson.section||'core'))?.tier||'essential';
export function recordAttempt(previous,attempt,now=Date.now()){
 const r={...previous};const independent=attempt.success&&attempt.hints===0&&attempt.mistakes===0&&(attempt.retries||0)===0&&(attempt.refutations||0)===0;
 r.attempts=(r.attempts||0)+1;r.last=now;r.lastHints=attempt.hints||0;r.lastMistakes=attempt.mistakes||0;r.lastRetries=attempt.retries||0;r.lastRefutations=attempt.refutations||0;
 r.passed=!!r.passed||attempt.success;r.successes=(r.successes||0)+(attempt.success?1:0);r.lastOutcome=attempt.success?(independent?'independent':'assisted'):'unfinished-goal';
 if(attempt.success){if(independent){r.independentSuccesses=(r.independentSuccesses||0)+1;r.independentStreak=(r.independentStreak||0)+1;r.lastIndependent=now;}else{r.assistedSuccesses=(r.assistedSuccesses||0)+1;r.lastAssisted=now;r.independentStreak=0;}}
 else r.independentStreak=0;
 // Legacy flags stay intact; old completions are never silently promoted to independent ones.
 r.streak=independent?r.independentStreak:0;return r;
}
export function progressState(r={}){
 if((r.independentSuccesses||0)>0)return 'independent';
 if((r.assistedSuccesses||0)>0)return 'assisted';
 if(r.passed)return 'legacy';
 return r.seen?'seen':'new';
}
export function reviewDue(r={},now=Date.now()){
 if(!r.independentSuccesses)return !!(r.passed||r.seen||r.attempts);
 if(r.lastOutcome&&r.lastOutcome!=='independent'&&(r.last||0)>=(r.lastIndependent||0))return true;
 const days=r.independentStreak>=3?7:r.independentStreak>=2?3:1;
 return now-(r.lastIndependent||0)>=days*86400000;
}
export function nextInSection(lessons,id){const l=lessons.find(x=>x.id===id);if(!l)return null;const section=lessons.filter(x=>(x.section||'core')===(l.section||'core'));return section[section.findIndex(x=>x.id===id)+1]||null;}
export function makeExercises(lessons,transfer){
 return [...lessons.map(l=>({...l,id:l.id,lessonId:l.id,kind:'lesson',exerciseKind:'demonstration-start',progressKey:l.id})),...transfer.map(e=>{const parent=lessons.find(l=>l.id===e.lessonId);if(!parent)throw new Error('Unmapped practice position: '+e.id);return {...parent,...e,section:parent.section||'core',kind:'exercise',progressKey:'exercise:'+e.id};})];
}
export function sanitizeBackup(data,validKeys,now=Date.now()){
 if(data?.app!=='endgame-lab-v2'||![1,2].includes(data.version)||!data.progress||typeof data.progress!=='object'||Array.isArray(data.progress))throw new Error('This is not an Endgame Lab V2 backup.');
 const clean={};for(const key of validKeys){const r=data.progress[key];if(!r||typeof r!=='object'||Array.isArray(r))continue;const c={};
 for(const k of ['seen','passed'])c[k]=r[k]===true;
 for(const k of ['attempts','successes','streak','last','lastHints','lastMistakes','lastRetries','lastRefutations','independentSuccesses','assistedSuccesses','independentStreak','lastIndependent','lastAssisted'])c[k]=Number.isFinite(r[k])&&r[k]>=0?Math.min(r[k],['last','lastIndependent','lastAssisted'].includes(k)?now:100000):0;
 if(['independent','assisted','unfinished-goal'].includes(r.lastOutcome))c.lastOutcome=r.lastOutcome;clean[key]=c;}
 return clean;
}
export function aggregateLesson(lessonId,exercises,progress){const records=exercises.filter(e=>e.lessonId===lessonId).map(e=>progress[e.progressKey]||{});return {seen:!!progress[lessonId]?.seen,independent:records.some(r=>r.independentSuccesses>0),assisted:records.some(r=>r.assistedSuccesses>0),legacy:records.some(r=>r.passed&&!r.independentSuccesses&&!r.assistedSuccesses),attempts:records.reduce((n,r)=>n+(r.attempts||0),0),review:records.some(r=>reviewDue(r)),transfers:exercises.filter(e=>e.lessonId===lessonId&&e.exerciseKind==='transfer').length,transferPassed:exercises.filter(e=>e.lessonId===lessonId&&e.exerciseKind==='transfer'&&progress[e.progressKey]?.independentSuccesses>0).length};}
export function continuationNote(before,move,after){
 const names={p:'pawn',n:'knight',b:'bishop',r:'rook',q:'queen',k:'king'};
 if(after.isCheckmate())return 'Checkmate: the king has no legal response to the check.';
 if(after.isStalemate())return 'Stalemate: the king is not in check and there are no legal moves. The game is drawn.';
 if(after.isInsufficientMaterial())return (move.captured?`The ${names[move.captured]} is captured. `:'')+'The remaining material cannot deliver checkmate. This is a draw.';
 if(move.captured)return `${move.color==='w'?'White':'Black'} captures the ${names[move.captured]} on ${capturedSquare(move)}${after.isCheck()?' with check':''}. This is a concrete consequence to compare with the position before your mistake.`;
 if(before.moves().length===1)return 'This is the only legal move in this position.';
 if(move.promotion)return `The pawn promotes to a ${names[move.promotion]}. Check the resulting position rather than assuming every promotion wins.`;
 if(after.isCheck())return 'The check forces the opponent to answer it before pursuing another plan.';
 return 'One calculated continuation against accurate resistance. Other moves can share the same outcome; this is not claimed to be forced.';
}
export async function calculateRefutation(fen,oracle,isCurrent=()=>true,maxPlies=4){
 const c=new Chess(fen),moves=[];let exact=true;
 for(let i=0;i<maxPlies&&!c.isGameOver();i++){
  if(!isCurrent())return null;
  const r=await oracle.reply(c.fen());if(!isCurrent())return null;
  if(!r.best||r.best==='(none)')break;
  const before=new Chess(c.fen());const m=c.move(uciMove(r.best));if(r.source!=='tablebase'||categoryValue(r.category)===null)exact=false;
  moves.push({uci:r.best,san:m.san,fen:c.fen(),text:continuationNote(before,m,c)});
 }
 return {startFen:fen,moves,index:0,exact};
}
export function publishedReplay(example){
 const c=new Chess(example.fen),moves=[];
 for(const step of example.line){const m=c.move(typeof step==='string'?step:step.san);moves.push({uci:m.from+m.to+(m.promotion||''),san:m.san,fen:c.fen(),text:step.text||example.explanation||'Compare this published continuation with the main line.'});}
 return {startFen:example.fen,moves,index:0,published:true,source:example.source,intro:example.explanation};
}
export function mergeProgress(existing,incoming){
 const out={...existing};for(const [key,newer] of Object.entries(incoming)){
  const old=out[key]||{},recent=(newer.last||0)>(old.last||0)?newer:old,merged={...old,...newer,...recent};
  for(const field of ['seen','passed'])merged[field]=!!old[field]||!!newer[field];
  for(const field of ['attempts','successes','independentSuccesses','assistedSuccesses','last','lastIndependent','lastAssisted'])merged[field]=Math.max(old[field]||0,newer[field]||0);
  out[key]=merged;
 }return out;
}
